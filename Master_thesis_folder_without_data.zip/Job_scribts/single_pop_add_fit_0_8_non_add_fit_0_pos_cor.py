# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 20:21:38 2022

@author: jerome
"""
import consumer_resource_model as crm
import random as rd
import numpy as np

seed = 52

rd.seed(seed)
np.random.seed(seed)

#%% standart Parameters for for model

# Number of sites that can differ
site_num       = 7
# Population distribution mean
pop_dist_mean  = 10000
# Number of resources
res_num        = 2
# Ressours distribution mean
res_dist_mean  = 5000
# Number of possible aminoacides on each site
max_site_var   = 2
# Fitness of the optimal Genotype
opt_fit        = 3
# Standart deviation of non additive effects
stand_dev      = 0.2
# Distribution mean of non additive effects
dist_mean      = 0
# Standart distribution for the fitness influence of the site
stand_dev_fit  = 0.2
# Distribution mean of the fitness influence of the site
dist_mean_fit  = 0.2
# Mutation rate, chance for a individual to mutate to a other genotype
mut_rate       = 4 * 10 ** (- 3)
# Number of generations
num_generation = 1000
# Number of repeats
rep_sim        = 300

#%% Run model with additive fitness of 0.8, epistasis sd of 0, positive correlation, a single start population and mutation rate of 4 * 10 ** (- 3)

stand_dev = 0
dist_mean_fit = 0.8

dif_cor = ["pos_cor"]

for cor_types in dif_cor:
        
    name_str = str(cor_types + 
                   "_single_pop" +
                   "_non_add_" + 
                   str(stand_dev).replace(".", "_") + 
                   "_add_" + 
                   str(dist_mean_fit).replace(".", "_"))
        
    res_list = crm.res_list_fun(res_dist_mean, res_num)
    pop_list = np.zeros(2 ** site_num)
    pop_list[rd.randint(0, len(pop_list))] = pop_dist_mean
        
    crm.multi_run(name_str, pop_list, res_list, site_num, num_generation, mut_rate, stand_dev_fit, dist_mean_fit, opt_fit, dist_mean, stand_dev, rep_sim)
        
