#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1GB
#SBATCH --job-name="CRM"
#SBATCH --error=%x_%j.err

sbatch crm_test.sh