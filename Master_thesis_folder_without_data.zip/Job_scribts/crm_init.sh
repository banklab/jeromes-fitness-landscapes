#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8GB
#SBATCH --job-name="CRM"
#SBATCH --time=00:30:00
#SBATCH --error=%x_%j.err

sbatch crm_test_init.sh &
sbatch crm_multy_pop_init.sh &
sbatch crm_single_pop_init.sh
