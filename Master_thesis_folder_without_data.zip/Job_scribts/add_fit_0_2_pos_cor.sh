#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8GB
#SBATCH --job-name="CRM"
#SBATCH --time=3-23:00:00
#SBATCH --error=%x_%j.err

# Load Anaconda3
module load Anaconda3
eval "$(conda shell.bash hook)"

# Load environment
conda activate mialab

# Run code
srun python3 add_fit_0_2_pos_cor.py