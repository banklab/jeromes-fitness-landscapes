#!/bin/bash
#SBATCH --ntasks=4
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1GB
#SBATCH --job-name="CRM"
#SBATCH --time=00:30:00
#SBATCH --error=%x_%j.err

sbatch crm_test.sh &
sbatch test_neg_cor.sh &
sbatch test_no_cor.sh &
sbatch test_pos_cor.sh



