#!/bin/bash

PATH+=:/c/Users/jerom/AppData/Local/Microsoft/WindowsApps/python

# Run code
python3 non_add_0.py &
python3 non_add_0_2.py &
python3 non_add_0_4.py &
python3 non_add_0_6.py &
python3 non_add_0_8.py &

python3 mut_rate_exp_1.py &
python3 mut_rate_exp_2.py &
python3 mut_rate_exp_3.py &
python3 mut_rate_exp_4.py &
python3 mut_rate_exp_5.py &

python3 add_fit_0.py &
python3 add_fit_0_2.py &
python3 add_fit_0_4.py &
python3 add_fit_0_6.py &
python3 add_fit_0_8.py &

python3 add_fit_0_non_add_fit_0.py &
python3 add_fit_0_2_non_add_fit_0_2.py &
python3 add_fit_0_4_non_add_fit_0_4.py &
python3 add_fit_0_6_non_add_fit_0_6.py &
python3 add_fit_0_8_non_add_fit_0_8.py &

python3 single_pop_mut_rate_exp_1.py &
python3 single_pop_mut_rate_exp_2.py &
python3 single_pop_mut_rate_exp_3.py &
python3 single_pop_mut_rate_exp_4.py &
python3 single_pop_mut_rate_exp_5.py &

python3 add_fit_0_8_non_add_fit_0_0.py &
python3 add_fit_0_6_non_add_fit_0_2.py &
python3 add_fit_0_2_non_add_fit_0_6.py &
python3 add_fit_0_0_non_add_fit_0_8.py &

python3 single_pop.py &
python3 single_run.py 

wait



