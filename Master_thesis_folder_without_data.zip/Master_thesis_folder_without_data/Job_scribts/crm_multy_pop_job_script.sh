#!/bin/bash
#SBATCH --ntasks=25
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8GB
#SBATCH --job-name="CRM"
#SBATCH --time=3-23:00:00
#SBATCH --error=%x_%j.err

# Load Anaconda3
module load Anaconda3
eval "$(conda shell.bash hook)"

# Load environment
conda activate mialab

# Run code
srun python3 non_add_0.py &
srun python3 non_add_0_2.py &
srun python3 non_add_0_4.py &
srun python3 non_add_0_6.py &
srun python3 non_add_0_8.py &

srun python3 mut_rate_exp_1.py &
srun python3 mut_rate_exp_2.py &
srun python3 mut_rate_exp_3.py &
srun python3 mut_rate_exp_4.py &
srun python3 mut_rate_exp_5.py &

srun python3 add_fit_0.py &
srun python3 add_fit_0_2.py &
srun python3 add_fit_0_4.py &
srun python3 add_fit_0_6.py &
srun python3 add_fit_0_8.py &

srun python3 add_fit_0_non_add_fit_0.py &
srun python3 add_fit_0_2_non_add_fit_0_2.py &
srun python3 add_fit_0_4_non_add_fit_0_4.py &
srun python3 add_fit_0_6_non_add_fit_0_6.py &
srun python3 add_fit_0_8_non_add_fit_0_8.py &

srun python3 add_fit_0_8_non_add_fit_0_0.py &
srun python3 add_fit_0_6_non_add_fit_0_2.py &
srun python3 add_fit_0_2_non_add_fit_0_6.py &
srun python3 add_fit_0_0_non_add_fit_0_8.py &

srun python3 single_run.py

wait


