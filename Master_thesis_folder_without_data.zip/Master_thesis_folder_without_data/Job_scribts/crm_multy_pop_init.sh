#!/bin/bash
#SBATCH --ntasks=75
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8GB
#SBATCH --job-name="CRM"
#SBATCH --time=00:30:00
#SBATCH --error=%x_%j.err

sbatch add_fit_0_0_non_add_fit_0_8_neg_cor.sh &
sbatch add_fit_0_0_non_add_fit_0_8_no_cor.sh &
sbatch add_fit_0_0_non_add_fit_0_8_pos_cor.sh &
sbatch add_fit_0_2_neg_cor.sh &
sbatch add_fit_0_2_no_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_2_neg_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_2_no_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_2_pos_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_6_neg_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_6_no_cor.sh &
sbatch add_fit_0_2_non_add_fit_0_6_pos_cor.sh &
sbatch add_fit_0_2_pos_cor.sh &
sbatch add_fit_0_4_neg_cor.sh &
sbatch add_fit_0_4_no_cor.sh &
sbatch add_fit_0_4_non_add_fit_0_4_neg_cor.sh &
sbatch add_fit_0_4_non_add_fit_0_4_no_cor.sh &
sbatch add_fit_0_4_non_add_fit_0_4_pos_cor.sh &
sbatch add_fit_0_4_pos_cor.sh &
sbatch add_fit_0_6_neg_cor.sh &
sbatch add_fit_0_6_no_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_2_neg_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_2_no_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_2_pos_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_6_neg_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_6_no_cor.sh &
sbatch add_fit_0_6_non_add_fit_0_6_pos_cor.sh &
sbatch add_fit_0_6_pos_cor.sh &
sbatch add_fit_0_8_neg_cor.sh &
sbatch add_fit_0_8_no_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_8_neg_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_8_no_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_8_pos_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_neg_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_no_cor.sh &
sbatch add_fit_0_8_non_add_fit_0_pos_cor.sh &
sbatch add_fit_0_8_pos_cor.sh &
sbatch add_fit_0_neg_cor.sh &
sbatch add_fit_0_no_cor.sh &
sbatch add_fit_0_non_add_fit_0_neg_cor.sh &
sbatch add_fit_0_non_add_fit_0_no_cor.sh &
sbatch add_fit_0_non_add_fit_0_pos_cor.sh &
sbatch add_fit_0_pos_cor.sh &
sbatch mut_rate_exp_1_neg_cor.sh &
sbatch mut_rate_exp_1_no_cor.sh &
sbatch mut_rate_exp_1_pos_cor.sh &
sbatch mut_rate_exp_2_neg_cor.sh &
sbatch mut_rate_exp_2_no_cor.sh &
sbatch mut_rate_exp_2_pos_cor.sh &
sbatch mut_rate_exp_3_neg_cor.sh &
sbatch mut_rate_exp_3_no_cor.sh &
sbatch mut_rate_exp_3_pos_cor.sh &
sbatch mut_rate_exp_4_neg_cor.sh &
sbatch mut_rate_exp_4_no_cor.sh &
sbatch mut_rate_exp_4_pos_cor.sh &
sbatch mut_rate_exp_5_neg_cor.sh &
sbatch mut_rate_exp_5_no_cor.sh &
sbatch mut_rate_exp_5_pos_cor.sh &
sbatch non_add_0_2_neg_cor.sh &
sbatch non_add_0_2_no_cor.sh &
sbatch non_add_0_2_pos_cor.sh &
sbatch non_add_0_4_neg_cor.sh &
sbatch non_add_0_4_no_cor.sh &
sbatch non_add_0_4_pos_cor.sh &
sbatch non_add_0_6_neg_cor.sh &
sbatch non_add_0_6_no_cor.sh &
sbatch non_add_0_6_pos_cor.sh &
sbatch non_add_0_8_neg_cor.sh &
sbatch non_add_0_8_no_cor.sh &
sbatch non_add_0_8_pos_cor.sh &
sbatch non_add_0_neg_cor.sh &
sbatch non_add_0_no_cor.sh &
sbatch non_add_0_pos_cor.sh &
sbatch single_run_neg_cor.sh &
sbatch single_run_no_cor.sh &
sbatch single_run_pos_cor.sh
