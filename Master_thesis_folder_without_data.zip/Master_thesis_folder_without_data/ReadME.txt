(temporary)ReadMe file: Theoratical ecology and evolution research practical (Jerome & Ivan)



This Project folder contains.....




Code: Once as an HTML-file and once as Rmd-file both with annotations.

-Most generated tables were not printed in the HTML file since their size would be disturbing. 

-Figures can be different to the ones in the presentation and the report, 
 since some values are generated randomly and also depend on given parameters and the created SV-value vector.
 


Presentation slides: Slides of the presentation given during the practical



Report: A first draft of the report including author contributions


Authors:  Ivan Spöcker & Jérôme Stäheli
Occasion: Theoretical ecology and evolution, research practical
Started:  13. Okt 2020
Endet:    12.12.2020


