# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 01:26:07 2022

@author: jerom
"""

import numpy as np
import glob
import os
import pandas as pd
import matplotlib.pyplot as plt
import pathlib
import itertools as it
import scipy.stats as sci

#%% Set script path

# path of script
cur_file_path = os.path.realpath(__file__)
#directory of script
cur_dir = os.path.dirname(cur_file_path)
# change wd
os.chdir(cur_dir)
# save directory
folder_path = str(pathlib.Path().resolve()) + '\\'
file_name = '\\statistical_data\\number_of_surviving_genotypes.csv'


#%%

data_folder_names = ['additive_fitness', 'both_fitness', 'non_additive_fitness']

number_of_surviving_genotypes = pd.DataFrame({})

for data_folder_name in data_folder_names:

    temp_df = pd.read_csv(folder_path + data_folder_name + file_name, header = [0,1], index_col=[0])

    number_of_surviving_genotypes = pd.concat([number_of_surviving_genotypes, temp_df], axis=1)
    
number_of_surviving_genotypes = number_of_surviving_genotypes.loc[:,~number_of_surviving_genotypes.columns.duplicated()]


#%%

correlation_data = pd.read_csv(folder_path + 'correlation_data.csv', header = [0,1], index_col=[0])

correlation_data = correlation_data.loc[:,~correlation_data.columns.duplicated()]

#%%

surviving_population_and_correlation_of_resouces = pd.DataFrame({})

for parameters, repeat in number_of_surviving_genotypes:

    surviving_population = np.min(number_of_surviving_genotypes[parameters][repeat].tail(100))
    correlation = correlation_data[parameters.replace('pop_list', 'phenotype_list')][repeat]
    surviving_population_and_correlation = pd.Series([surviving_population, correlation])
    
    surviving_population_and_correlation_of_resouces[parameters, repeat] = surviving_population_and_correlation


#%%

plt.scatter(surviving_population_and_correlation_of_resouces.iloc(0)[1], surviving_population_and_correlation_of_resouces.iloc(0)[0])

plt.show()

#%%

values_sorted_by_correlation = {}



print(surviving_population_and_correlation_of_resouces.iloc(0)[1])

#%%

correlations = np.zeros(len(surviving_population_and_correlation_of_resouces.iloc(0)[1]), dtype = float)

for numbers in range(len(correlations)):
    
    correlations[numbers] = surviving_population_and_correlation_of_resouces.iloc(0)[1][numbers]

surviving_phenotypes = np.zeros(len(surviving_population_and_correlation_of_resouces.iloc(0)[1]), dtype = int)

for numbers in range(len(correlations)):
    
    surviving_phenotypes[numbers] = surviving_population_and_correlation_of_resouces.iloc(0)[0][numbers]


quantiles = np.asarray(range(1, 101, 1))/100
quantiles_correlation = np.zeros(len(quantiles), dtype = float)

for quant in range(len(quantiles)):
    
    quantiles_correlation[quant] = np.quantile(correlations, quantiles[quant])
    
mean_per_quantile = np.zeros(len(quantiles), dtype = float)
sd_per_quantile = np.zeros(len(quantiles), dtype = float)

for quant in range(len(quantiles)):
    
    current_list = []
    
    for runs in range(len(surviving_phenotypes)):
        
        if quant == 0:
            
            if quantiles_correlation[quant] > correlations[runs]:
                
                current_list.append(surviving_phenotypes[runs])
        
        else:
            if quantiles_correlation[quant] > correlations[runs] >  quantiles_correlation[quant - 1]:
                
                current_list.append(surviving_phenotypes[runs])
    
    current_array = np.asarray(current_list)
    
    sd_per_quantile[quant] = np.std(current_array)
    mean_per_quantile[quant] = np.mean(current_array)

#%%

plt.scatter(correlations, surviving_phenotypes)
plt.plot(quantiles_correlation, mean_per_quantile, color = 'red')
plt.fill_between(quantiles_correlation, mean_per_quantile + sd_per_quantile, mean_per_quantile - sd_per_quantile, color = 'red', alpha = 0.2)

plt.xticks(fontsize=12)
plt.yticks([1, 2, 3, 4], fontsize=12, rotation=90)


plt.xlabel('Ressource correlatinge to each other', fontsize = 13)
plt.ylabel('Number of surviving phenotypes', fontsize = 13)

plt.show()



#%%

surviving_population_data = np.asarray(surviving_population_and_correlation_of_resouces.iloc(0)[0])

resource_correlation_data = np.zeros(len(surviving_population_data))

for number in range(len(np.asarray(surviving_population_and_correlation_of_resouces.iloc(0)[1]))):
    resource_correlation_data[number] = np.asarray(surviving_population_and_correlation_of_resouces.iloc(0)[1])[number]

print(surviving_population_and_correlation_of_resouces)
print(surviving_population_data)
print(resource_correlation_data)

#%%

print(sci.pearsonr(resource_correlation_data, surviving_population_data))



