# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 01:26:07 2022

@author: jerom
"""

# load packeges needed
import numpy as np
import glob
import os
import pandas as pd
import consumer_resource_model as crm
import matplotlib.pyplot as plt
import rough_mount_fuji as rmf
import pathlib
import itertools as it
import json
import scipy.stats as sci

#%% Set script path

# path of script
cur_file_path = os.path.realpath(__file__)
#directory of script
cur_dir = os.path.dirname(cur_file_path)
# change wd
os.chdir(cur_dir)
# save directory
save_path = str(pathlib.Path().resolve()) + '\\correlation\\'
folder_path = str(pathlib.Path().resolve()) + '\\'
file_name = '\\statistical_data\\'

# loads ever population
population_data = {}
for np_file_name in glob.glob('*.np[yz]'):
    population_data[np_file_name] = np.load(np_file_name)

# load runs and repeats
first_key = list(population_data.keys())[0]
number_of_repeats = range(len(population_data[first_key]))

#%% callculates the correlatin betweenressources with np.corrcoef function and saves the result in a dataframe and as a cvs inside correlation folder

correlation_between_ressources = pd.DataFrame({})

for run in population_data:
    
    correlation_between_ressources_temp = pd.DataFrame({})
    
    for repeat in number_of_repeats:
        
        current_data = population_data[run][repeat]
        
        correlation_between_ressources_temp['repeat_' + str(repeat + 1)] = np.asarray([np.corrcoef(current_data[0], current_data[1])[0,1]])
        
        
    correlation_between_ressources_temp.columns = pd.MultiIndex.from_arrays([[run] * len(correlation_between_ressources_temp.columns), correlation_between_ressources_temp.columns])
    correlation_between_ressources = pd.concat([correlation_between_ressources, correlation_between_ressources_temp], axis=1)

correlation_between_ressources.to_csv(save_path + 'correlation_data.csv')


#%% loads statistical analysis data index output

data_folder_names = ['additive_fitness', 'mut_rates', 'both_fitness', 'non_additive_fitness']

index_of_surviving_genotypes = pd.DataFrame({})

for data_folder_name in data_folder_names:

    temp_df = pd.read_csv(folder_path + 'multi_pop\\' + data_folder_name + file_name + 'index_of_surviving_genotypes.csv', header = [0,1], index_col=[0], dtype=object,)

    index_of_surviving_genotypes = pd.concat([index_of_surviving_genotypes, temp_df], axis=1)
    
index_of_surviving_genotypes = index_of_surviving_genotypes.loc[:,~index_of_surviving_genotypes.columns.duplicated()]

index_of_surviving_genotypes = index_of_surviving_genotypes.loc[:,~index_of_surviving_genotypes.columns.duplicated()]

#%% loads statistical analysis number of surviving genotypes output

data_folder_names = ['additive_fitness', 'mut_rates', 'both_fitness', 'non_additive_fitness']

number_of_surviving_genotypes = pd.DataFrame({})

for data_folder_name in data_folder_names:

    temp_df = pd.read_csv(folder_path + 'multi_pop\\' + data_folder_name + file_name + 'number_of_surviving_genotypes.csv', header = [0,1], index_col=[0])

    number_of_surviving_genotypes = pd.concat([number_of_surviving_genotypes, temp_df], axis=1)
    
number_of_surviving_genotypes = number_of_surviving_genotypes.loc[:,~number_of_surviving_genotypes.columns.duplicated()]

#%% splits the index string so indexes can be used

index_surviving_populations = {}

for run in number_of_surviving_genotypes:
    
    smallest_number_of_populations = number_of_surviving_genotypes[run].tail(100).argmin()
    
    index_surviving_populations[run] = (index_of_surviving_genotypes[run].tail(100)[smallest_number_of_populations + (len(index_of_surviving_genotypes) - 100)]).split('_')

#%% plots all runs with 3 or more phenotypes surviving in an plot with all phenotypes visible

points = []

for run in index_surviving_populations:
    
    exery_index = index_surviving_populations[run]
    
    if len(exery_index) >= 3:
        
        first_ressource_list = []
        second_ressource_list = []
        
        for index in exery_index:
        
            population_data_parameters = run[0].replace('pop_list', 'phenotype_list')
            population_data_repeat = int(run[1].split('_')[1]) - 1
        
            first_ressource = population_data[population_data_parameters][population_data_repeat][0][int(index)]
            second_ressource = population_data[population_data_parameters][population_data_repeat][1][int(index)]
            
            plt.scatter(first_ressource, second_ressource)
            
            first_ressource_list.append(first_ressource)
            second_ressource_list.append(second_ressource)

            points.append([first_ressource, second_ressource])
        
        first_ressource_array = np.asarray(first_ressource_list)
        second_ressource_array = np.asarray(second_ressource_list)
        
        slope, intercept = np.polyfit([np.max(first_ressource_array), first_ressource_array[np.argmax(second_ressource_array)]], 
                                      [second_ressource_array[np.argmax(first_ressource_array)], np.max(second_ressource_array)], 1)
        
        x_points = population_data[population_data_parameters][population_data_repeat][0]

        plt.plot(x_points, x_points * slope + intercept, color = 'black', alpha = 0.4)
        plt. scatter(x_points, population_data[population_data_parameters][population_data_repeat][1], color = 'grey', alpha = 0.3)
        
        plt.xlabel('Uptake resource 1', fontsize = 13)
        plt.ylabel('Uptake resource 2', fontsize = 13)
        
        plt.show()
        
points = np.asarray(points)


#%% plots all the surviving phenotypes of all

points = []

for run in index_surviving_populations:
    
    exery_index = index_surviving_populations[run]
    
    if len(exery_index) >= 3:
        
        first_ressource = np.zeros(len(exery_index), dtype = float)
        second_ressource = np.zeros(len(exery_index), dtype = float)
    
        for index in range(len(exery_index)):
        
            population_data_parameters = run[0].replace('pop_list', 'phenotype_list')
            population_data_repeat = int(run[1].split('_')[1]) - 1
        
            first_ressource[index] = population_data[population_data_parameters][population_data_repeat][0][int(exery_index[index])]
            second_ressource[index] = population_data[population_data_parameters][population_data_repeat][1][int(exery_index[index])]
        
        first_ressource = first_ressource / np.mean(first_ressource)
        second_ressource = second_ressource / np.mean(second_ressource)
        
        plt.scatter(first_ressource, second_ressource)
        
        plt.xlabel('Uptake resource 1', fontsize = 13)
        plt.ylabel('Uptake resource 2', fontsize = 13)
            
        points.append([first_ressource, second_ressource])
            
plt.show()
        
#%% plots only the phenotypes surviving for some runs at once


count = 0
name_tag = []

for data_point in points:
    
    plt.scatter(data_point[0], data_point[1], alpha = 0.8)
    plt.plot([np.max(data_point[0]), data_point[0][np.argmax(data_point[1])]], 
             [data_point[1][np.argmax(data_point[0])], np.max(data_point[1])], 
             alpha = 0.4)
    
    count += 1
    
    if count >= len(points) / 30:
        
        count = 0
        
        plt.xlabel('Uptake resource 1', fontsize = 13)
        plt.ylabel('Uptake resource 2', fontsize = 13)
        
        plt.axis('square')
        
        plt.show()
        
        name_tag.append(chr(97 + len(name_tag)))

if count != 0:
    
    plt.xlabel('Uptake resource 1', fontsize = 13)
    plt.ylabel('Uptake resource 2', fontsize = 13)

    plt.axis('square')
    
    plt.show()
    

