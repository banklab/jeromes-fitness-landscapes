# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 01:26:07 2022

@author: jerom
"""

import numpy as np
import glob
import pathlib
import os
import pandas as pd
import matplotlib.pyplot as plt
import itertools as it
import scipy.stats as sci




#%% Set script path

# path of script
cur_file_path = os.path.realpath(__file__)
# directory of script
cur_dir = os.path.dirname(cur_file_path)
# change wd
os.chdir(cur_dir)
# save directory
save_path = str(pathlib.Path().resolve()) + '\\statistical_data\\'

# loads all .np[yz] within the same folder
population_data = {}
for np_file_name in glob.glob('*.np[yz]'):
    population_data[np_file_name] = np.load(np_file_name)

# counts the number of runs, repeats and genotypes
first_key = list(population_data.keys())[0]
number_of_genotypes = range(len(population_data[first_key][0][0]))
number_of_repeats = range(len(population_data[first_key]))
number_of_generations = range(len(population_data[first_key][0]))

#%% measures of diversity if the data for the shannon index and haplotype diversity is needed

'''
import consumer_resource_model as crm
import rough_mount_fuji as rmf

shannon_data = pd.DataFrame({})
haplotype_data = pd.DataFrame({})
nucleotide_data = pd.DataFrame({})

for run in population_data:
    
    shannon_data_temp = pd.DataFrame({})
    haplotype_data_temp = pd.DataFrame({})
    nucleotide_data_temp = pd.DataFrame({})
    
    
    for repeat in number_of_repeats:
        
        shannon_data_temp['repeat_' + str(repeat + 1)] = crm.shannon_diversity(population_data[run][repeat])
        haplotype_data_temp['repeat_' + str(repeat + 1)] = crm.haplotype_diversity(population_data[run][repeat])
        #nucleotide_data_temp['repeat_' + str(repeat + 1)] = crm.nucleotide_diversity(population_data[run][repeat], rmf.genotypes_list(7))
    
  
    
    shannon_data_temp.columns = pd.MultiIndex.from_arrays([[run] * len(shannon_data_temp.columns), shannon_data_temp.columns])
    shannon_data = pd.concat([shannon_data, shannon_data_temp], axis=1)
    
    haplotype_data_temp.columns = pd.MultiIndex.from_arrays([[run] * len(haplotype_data_temp.columns), haplotype_data_temp.columns])
    haplotype_data = pd.concat([haplotype_data, haplotype_data_temp], axis=1)
    
'''



#%%

# empty dataframes to save the index of surviving genotypes and number of surviving genotypes
number_of_surviving_genotypes = pd.DataFrame({})
index_of_surviving_genotypes = pd.DataFrame({})

# empty array to save the number of surviving genotypes per generation and string to save the index of surviving genotypes
number_of_surviving_genotypes_per_generation = np.zeros(len(number_of_generations))
index_sting = [''] * len(number_of_generations)

# diffrent mutation exponents writing methods
mutation_exponents = ['1', '2', '3', '4', '5', '0_4', '0_04', '0_004', '4e-05']

# Checks every population in every run in every repeat
for run in population_data:
    
    number_of_surviving_genotypes_temp = pd.DataFrame({})
    index_of_surviving_genotypes_temp = pd.DataFrame({})
    
    for repeat in number_of_repeats:
        
        for generation in number_of_generations:
            
            # counts populations that have higher number of individuals bigger than the largest population times mutation rate divided by the number of possible mutations
            # Saves the number of surviving populations and their index            
            if 'mut_rate_' not in run:
            
                minimum_population_size = (np.max(population_data[run][repeat][generation]) * (4 / 7) * (10 ** -4)) + 10  
                
                surviving_populations = population_data[run][repeat][generation] > minimum_population_size
                
                number_of_surviving_genotypes_per_generation[generation] = np.count_nonzero(surviving_populations)
                
                index_surviving_population = list(it.compress(range(len(surviving_populations)), surviving_populations))
                                        
                index_sting[generation] = '_'.join(str(surviving_index) for surviving_index in index_surviving_population)
                
            else:
                
                for mutation_exponent in range(len(mutation_exponents)):
                    
                    if 'mut_rate_' + mutation_exponents[mutation_exponent] in run and len(mutation_exponents[mutation_exponent]) == 1:
                        
                        minimum_population_size = (np.max(population_data[run][repeat][generation]) * ((4 / 7) * (10 ** (-int(mutation_exponents[mutation_exponent]))))) + 10
                        
                        surviving_populations = population_data[run][repeat][generation] > minimum_population_size
                        
                        number_of_surviving_genotypes_per_generation[generation] = np.count_nonzero(surviving_populations)
                        
                        index_surviving_population = list(it.compress(range(len(surviving_populations)), surviving_populations))
                        
                        index_sting[generation] = '_'.join(str(surviving_index) for surviving_index in index_surviving_population)
                    
                    elif 'mut_rate_' + mutation_exponents[mutation_exponent] in run and len(mutation_exponents[mutation_exponent]) >= 3: 
                        
                        if '4e-05' in run:
                        
                            minimum_population_size = (np.max(population_data[run][repeat][generation]) * ((4 / 7) * (10 ** -5))) + 10
                        
                        elif len(mutation_exponents[mutation_exponent]) == 3:
                            minimum_population_size = (np.max(population_data[run][repeat][generation]) * ((4 / 7) * (10 ** -1))) + 10
                            
                        elif len(mutation_exponents[mutation_exponent]) == 4:
                            minimum_population_size = (np.max(population_data[run][repeat][generation]) * ((4 / 7) * (10 ** -2))) + 10
                            
                        else: 
                            minimum_population_size = (np.max(population_data[run][repeat][generation]) * ((4 / 7) * (10 ** -3))) + 10
                        
                        surviving_populations = population_data[run][repeat][generation] > minimum_population_size
                        
                        number_of_surviving_genotypes_per_generation[generation] = np.count_nonzero(surviving_populations)
                        
                        index_surviving_population = list(it.compress(range(len(surviving_populations)), surviving_populations))
                        
                        index_sting[generation] = '_'.join(str(surviving_index) for surviving_index in index_surviving_population)
              
        # Saves index and number as pd dataframe
        number_of_surviving_genotypes_temp['repeat_' + str(repeat + 1)] = number_of_surviving_genotypes_per_generation
        index_of_surviving_genotypes_temp['repeat_' + str(repeat + 1)] = index_sting

    # merges all into one dataframe
    number_of_surviving_genotypes_temp.columns = pd.MultiIndex.from_arrays([[run] * len(number_of_surviving_genotypes_temp.columns), number_of_surviving_genotypes_temp.columns])
    number_of_surviving_genotypes = pd.concat([number_of_surviving_genotypes, number_of_surviving_genotypes_temp], axis=1)

    index_of_surviving_genotypes_temp.columns = pd.MultiIndex.from_arrays([[run] * len(index_of_surviving_genotypes_temp.columns), index_of_surviving_genotypes_temp.columns])
    index_of_surviving_genotypes = pd.concat([index_of_surviving_genotypes, index_of_surviving_genotypes_temp], axis=1)



#%% make a set with all column names (run names / repeats)

diffrent_run_names = [''] * len(number_of_surviving_genotypes.columns)
diffrent_repeats = [''] * len(number_of_surviving_genotypes.columns)

count = 0

for name in number_of_surviving_genotypes.columns:
    
    diffrent_run_names[count] = name[0]
    diffrent_repeats[count] = name[1]
    
    count += 1
    
diffrent_run_names = list(set(diffrent_run_names))
diffrent_repeats = list(set(diffrent_repeats))


#%% checks if the number of surviving populations never went below 3 and saves the result

runs_with_three_genotypes_surviving = pd.DataFrame({})

for run in population_data:
    
    temporal = np.zeros(300, dtype = bool)
    
    for repeat in number_of_surviving_genotypes[run]:
        if (number_of_surviving_genotypes[run][repeat] >= 3).all():
            temporal[int(repeat.split('_')[1]) - 1] = True
            
    runs_with_three_genotypes_surviving[run] = temporal


#%% counts the number of times within a run 3 or more genotypes survived

time_three_genotypes_survives_temp = {}

for run in diffrent_run_names:
    time_three_genotypes_survives_temp[run] = np.sum(runs_with_three_genotypes_surviving[run])
    

time_three_genotypes_survives = pd.DataFrame(time_three_genotypes_survives_temp, index = [0])


#%% Saves all results as cvs files for further use

os.makedirs(save_path, exist_ok=True)
number_of_surviving_genotypes.to_csv(save_path + 'number_of_surviving_genotypes.csv')
runs_with_three_genotypes_surviving.to_csv(save_path + 'runs_with_three_genotypes_surviving.csv')
time_three_genotypes_survives.to_csv(save_path + 'time_three_genotypes_survives.csv')
index_of_surviving_genotypes.to_csv(save_path + 'index_of_surviving_genotypes.csv')

'''
shannon_data.to_csv(save_path + 'shannon_data.csv')
haplotype_data.to_csv(save_path + 'haplotype_data.csv')
'''


#%% Returns plot of every run more than 3 genotypes survive

print(runs_with_three_genotypes_surviving)

for run in runs_with_three_genotypes_surviving:
    for repeat in range(len(runs_with_three_genotypes_surviving[run])):
        if runs_with_three_genotypes_surviving[run][repeat]:
            
            
            
            plt.plot(population_data[run][repeat])
            # plt.title(str(run) + str(repeat))
            plt.xlabel('Generations')
            plt.ylabel('Individuals')
            
            plt.show()