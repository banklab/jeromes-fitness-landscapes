ReadME file: Master thesis (Jérôme R Stäheli)



This Project folder contains.....




Code (Folder):  

	Contains Python Files. 
	rough_mount_fuji.py contains the code for the rough Mt. Fuji model
	consumer_resource_model.py includes the code for the consumer resource model. 
	It has to be in the same folder as the rough_mount_fuji.py, since it uses it as a module.
	test.py contains a code that runs a single run and multiple runs. 
	You can open, change parameters, and run the test.py to see what the model does. 
	It has to be in the same folder as the consumer_resource_model.py or the rough_mount_fuji.py, since it uses them as modules.




Job_scribts (Folder):

	It contains the job scripts (.sh) that executed the .py files containing the instructions to run the code with the used parameters.
	Works on the Ubelix cluster of the University of Bern that uses Linux. If you want to run the job scripts on another cluster, check if the files can be run.
	To initiate all job scripts, submit the crm_init.sh. It will submit all the other job scripts.
	To only run the tests submit crm_test_init.sh.
	To only run the runs where it starts with a single phenotype, submit crm_single_pop_init.sh.
	To only run the runs where it starts with all phenotypes, are there submit crm_multy_pop_init.sh
	To only run a specific run, submit the .sh file with the parameters wanted in the title. 
	add_fit is additive fitness, non_add_fit is non-additive fitness (epistasis), and mut_rate_exp is the mutation rate exponent (10 ^ (mutation rate exponent)).
	If a parameter is not defined in a .sh files file name, then the parameter is 0.2 for additive fitness and non-additive fitness (epistasis) and -4 for the mutation rate exponent.




Model_output (Folder):

	It contains the data that was generated using the scripts, code and the Ubelix cluster.
	Diversity_plots (Folder):
		It contains plots of every run.
		Information about the pdf files that have _multirun before the .pdf:
			X-axis is the generation time. 
			Y-axis is the value of the diversity index. 
			The plots show the development of the Shannon index, haplotype diversity and nucleotide diversity throughout a run.
			The file name of the file indicates the values of the parameters.
			add_fit is additive fitness, non_add_fit is non-additive fitness (epistasis), and mut_rate_exp is the mutation rate exponent (10 ^ (mutation rate exponent)).
			neg_cor is negative correlation, pos_cor is positive correlation and no_cor is no correlation.
			If a parameter is not defined in a .sh files file name, then the parameter is 0.2 for additive fitness and non-additive fitness (epistasis) and -4 for the mutation rate exponent.
			If the file name contains single_pop, it is a run that started with a single phenotype.
		The pdf that does not have _multirun before the .pdf are test runs with a single parameter.
	Nucleotide_diversity (Folder):
		It contains the nucleotide diversity value data of every run as .npy files.
		The file name of the file indicates the values of the parameters.
		add_fit is additive fitness, non_add_fit is non-additive fitness (epistasis), and mut_rate_exp is the mutation rate exponent (10 ^ (mutation rate exponent)) or just the value in numbers.
		neg_cor is negative correlation, pos_cor is positive correlation and no_cor is no correlation.
		If a parameter is not defined in a .npy files file name, then the parameter is 0.2 for additive fitness and non-additive fitness (epistasis) and -4 for the mutation rate exponent.
		If the file name contains single_pop, it is a run that started with a single phenotype.

	Population_data (Folder):
		Information about the pdf files that have CRM_multi_run at the start of the file name:
			It contains the number of individuals for each phenotype in each generation as .npy files.
			The file name of the file indicates the values of the parameters.
			neg_cor is negative correlation, pos_cor is positive correlation and no_cor is no correlation.
			If a parameter is not defined in a .npy files file name, then the parameter is 0.2 for additive fitness and non-additive fitness (epistasis) and -4 for the mutation rate exponent.
			If the file name contains single_pop, it is a run that started with a single phenotype.
		Files with CRM_single_run are the output of test some.




Statistical_analysis (Folder):	

	It contains the data and the Python code that was used for statistical analysis
	Correlation_calculation (Folder):
		Folder with the data used to analyze the correlation of the uptake between two resources relating to the surviving phenotypes of the data.
		Data were split into five folders inside the multi_pop folder, depending on the changing parameters. 
		So, for example, mut_rates contains all runs where the difference between them is only the mutation rate and the correlation type.
		Folders are additive_fitness (additive fitness), both_fitness (additive fitness and non-additive fitness), mut_rates (mutations rates), and non_additive_fitness (non-additive fitness).
		Inside the folders is a statistical_analysis.py. 
		statistical_analysis.py calculates the number of surviving phenotypes, which runs have three or more phenotypes surviving, how many times three or more survive within a run and which phenotypes survive.
		statistical_analysis.py saves the newly created data in a statistical_data folder.
		statistical_analysis.py takes the data from the same location it is in and needs files from the Model_output/Population_data folder to work.
		statistical_analysis.py also creates a plot where the x-axis is the generations, the y-axis the number of individuals and the lines are single phenotypes (only shows runs with three or more surviving).
		statistical_analysis.py can also be modified to save the Shannon data and haplotype diversity of each generation of each run but needs rough_mount_fuji.py and consumer_resource_model.py in the same location for that to work.
		correlation_calculation.py uses the output of the statistical_analysis.py in the statistical_data and the data from the same location it is in and needs files from the Model_output/Population_data.
		correlation_calculation.py saves the created data inside a correlation_data.csv inside a correlation folder it creates in the same location as correlation_calculation.py
		correlation_calculation.py also puts out a plot where the point are the phenotypes, and the axis represents the ability to uptake one of the two resources in three variants (only runs with three or more surviving phenotypes are used). 
		The variance of the plots are once with all points from all the data, once with only one run at a time with all phenotypes shown and the surviving in colour and once with a part of all phenotypes
		phenotype_uptake_of_surviving_populations.py needs correlation_data.csv in the same location and the statistical_data folder created by statistical_analysis.py inside the five folders split by the parameters.
		phenotype_uptake_of_surviving_populations.py plots the number of surviving phenotypes (x-axis) against the correlation of the uptake between the two resources (y-axis). Each point represents one repeat of one run. 
		Also plots the mean number and standard deviation of surviving phenotypes per quantile.
		phenotype_uptake_of_surviving_populations.py prints out the Pearson correlation between the number of surviving phenotypes, the uptake correlation, and the corresponding p-value.
	Multi_populations (Folder): 
		It has the same layout as the Correlation_calculation/multi_pop folder, the only difference being that each parameter folder is inside another and contains a phenotype_uptake_of_surviving_populations.py.
		The one in the mut_rate folder and the non_additive_fitness folder is slightly different to show a plot of the mean surviving phenotypes (y-axis) and the parameter that changed between the runs (x-axis) with the standard deviation.
		It also prints the Pearson correlation, p-value and Cohen's d-value.
	Single_populations (Folder):
		It has the same layout as the Correlation_calculation/multi_pop folder, and the .py files function the same way.
	
		




Jeromes_Master_Thesis.pdf Containing the Master Thesis.





Authors:  Jérôme Stäheli
Occasion: Master Thesis
Endet:    13.02.2023


